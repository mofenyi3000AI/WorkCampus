(() => {
  const $ = (id) => document.getElementById(id);
  let me = null;
  let view = "home";
  let gigs = [];
  let selectedGig = null;

  async function api(path, opts = {}) {
    const res = await fetch(path, { credentials: "include", headers: { "Content-Type": "application/json", ...(opts.headers || {}) }, ...opts });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || "Request failed");
    }
    return res.json();
  }

  function toast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.classList.add("on");
    setTimeout(() => el.classList.remove("on"), 2800);
  }

  function go(name) {
    view = name;
    render();
    window.scrollTo(0, 0);
  }

  function header(title, sub) {
    return `<div class="topbar"><div class="brand"><img src="/assets/logo.jpg" alt="" /><div>${title}<small>${sub || "University of Limpopo"}</small></div></div><div class="pill live"><span class="dot"></span>Online</div></div>`;
  }

  async function loadMe() {
    try { const d = await api("/api/me"); me = d.user; } catch { me = null; }
  }

  async function loadGigs() {
    try { gigs = await api("/api/gigs"); } catch { gigs = []; }
  }

  function renderLogin() {
    return `
      ${header("Join or log in", "Verified UL students only")}
      <div class="card">
        <h3>Log in</h3>
        <div class="field"><label>Email</label><input id="l-email" type="email" /></div>
        <div class="field"><label>Password</label><input id="l-pass" type="password" /></div>
        <button class="btn gold" id="btn-login">Log in</button>
      </div>
      <div class="card">
        <h3>Join (free seeker)</h3>
        <p class="tiny">Name and student number stay with admin. Front of card + selfie only.</p>
        <div class="grid-2">
          <div class="field"><label>Name</label><input id="r-first" /></div>
          <div class="field"><label>Surname</label><input id="r-surname" /></div>
        </div>
        <div class="field"><label>Email</label><input id="r-email" type="email" /></div>
        <div class="field"><label>Password</label><input id="r-pass" type="password" /></div>
        <div class="field"><label>Student number</label><input id="r-num" /></div>
        <div class="field"><label>Course</label><input id="r-course" /></div>
        <div class="grid-2">
          <div class="field"><label>Year</label><select id="r-year"><option>1st year</option><option>2nd year</option><option>3rd year</option><option>4th year</option></select></div>
          <div class="field"><label>Stay</label><select id="r-stay"><option>On campus</option><option>Off campus</option></select></div>
        </div>
        <div class="field"><label>Gender</label><select id="r-gender"><option>Female</option><option>Male</option></select></div>
        <button class="btn teal" id="btn-register">Create free account</button>
      </div>`;
  }

  function renderHome() {
    return `
      ${header("Welcome", me ? me.first_name : "Campus")}
      <div class="hero">
        <h1>Solutions for student life.</h1>
        <p>Earn a little extra. Use the food bank when you need a plate. Build friendships that walk you home.</p>
        <div class="row"><span class="pill gold">${gigs.length} open gigs</span>${me ? `<span class="pill">${me.plan}</span>` : ""}</div>
      </div>
      <div class="cats">
        <button class="cat gigs" data-go="gigs"><b>Earn a little</b><span>Jobs from R30</span></button>
        <button class="cat walk" data-go="walk"><b>Walk together</b><span>Library or home</span></button>
        <button class="cat study" data-go="study"><b>Study help</b><span>Share a desk</span></button>
        <button class="cat plate" data-go="help"><b>Food bank</b><span>Quiet plate</span></button>
        <button class="cat move" data-go="gigs"><b>Move & bakkie</b><span>Boxes, lifts</span></button>
        <button class="cat meet" data-go="shop"><b>Shop & plans</b><span>Subscribe to post</span></button>
      </div>
      ${gigs.slice(0, 4).map(g => gigCard(g)).join("")}
    `;
  }

  function gigCard(g) {
    return `<article class="card tap" data-open-gig="${g.id}">
      <div class="between"><span class="tag">${g.cat}</span><div class="price">R${g.pay}</div></div>
      <h3>${g.title}</h3>
      <div class="meta">${g.where_text || ""} · ${g.when_text || ""}</div>
      <div class="meta">${g.public_label || "Verified student"}</div>
    </article>`;
  }

  function renderGigs() {
    return `${header("Campus gigs")}${gigs.map(gigCard).join("") || "<p>No gigs yet.</p>"}${me && me.plan !== "free" ? `<button class="fab" data-go="post">+</button>` : `<button class="fab" data-go="shop">+</button>`}`;
  }

  function renderGig() {
    const g = gigs.find(x => x.id == selectedGig);
    if (!g) return header("Gig") + "<p>Not found.</p>";
    return `
      ${header("Gig")}
      <div class="card">
        <div class="between"><span class="tag">${g.cat}</span><div class="price">R${g.pay}</div></div>
        <h2>${g.title}</h2>
        <p>${g.detail || ""}</p>
        <p class="meta">${g.where_text || ""} · ${g.when_text || ""}</p>
        <p class="meta">${g.public_label}</p>
        ${g.status === "open" && me && g.poster_id !== me.id ? `<button class="btn gold" id="btn-accept">Accept this job</button>` : ""}
        ${me && (me.is_admin || g.poster_id === me.id) ? `<div id="replies"></div><textarea id="reply-body" placeholder="Private reply"></textarea><button class="btn ghost" id="btn-reply">Send private reply</button>` : `<p class="tiny">Replies are private to the poster and admin.</p>`}
      </div>
      <button class="btn ghost" data-go="gigs">Back</button>`;
  }

  function renderPost() {
    if (!me || me.plan === "free") return `${header("Subscribe to post")}<div class="card"><p>Free accounts find work. Posting needs a plan.</p><button class="btn gold" data-go="shop">See plans</button></div>`;
    return `
      ${header("Post a job")}
      <div class="card">
        <div class="field"><label>What do you need?</label><input id="p-title" /></div>
        <div class="field"><label>Details</label><textarea id="p-detail"></textarea></div>
        <div class="field"><label>Pay (R)</label><input id="p-pay" type="number" value="100" /></div>
        <div class="field"><label>Type</label><select id="p-cat"><option value="chores">Chores</option><option value="move">Moving</option><option value="bakkie">Bakkie</option><option value="assign">Assignment</option><option value="other">Other</option></select></div>
        <div class="field"><label>Where</label><input id="p-where" /></div>
        <div class="field"><label>When</label><input id="p-when" /></div>
        <button class="btn gold" id="btn-post">Post</button>
      </div>`;
  }

  function renderShop() {
    return `
      ${header("Plans")}
      <div class="card"><p>Free = find work. Paid = post jobs and sell on the market.</p></div>
      <div class="plan"><h3>Poster</h3><div class="amt">R39<span class="tiny"> / mo</span></div><button class="btn sm gold" data-buy="poster-1m" data-amt="39">Subscribe</button></div>
      <div class="plan hot"><h3>Campus Pro</h3><div class="amt">R79<span class="tiny"> / mo</span></div><button class="btn sm gold" data-buy="pro-1m" data-amt="79">Subscribe</button></div>
      <p class="tiny">Payments go through PayFast. Successful payment upgrades your plan via the server webhook.</p>`;
  }

  function renderMe() {
    if (!me) return `${header("Me")}<button class="btn gold" data-go="login">Log in</button>`;
    return `
      ${header("Your card", me.plan)}
      <div class="card">
        <b>${me.first_name} ${me.surname || ""}</b>
        <div class="meta">${me.course || ""} · ${me.year || ""} · ${me.stay || ""}</div>
        <div class="tiny">Plan: ${me.plan}${me.plan_until ? " until " + new Date(me.plan_until).toLocaleDateString() : ""}</div>
      </div>
      <button class="btn gold" data-go="shop">Plans</button>
      ${me.is_admin ? `<button class="btn ghost" data-go="admin">Admin desk</button>` : ""}
      <button class="btn ghost" id="btn-logout">Log out</button>`;
  }

  function renderAdmin() {
    return `${header("Admin")}<div class="card"><p>Quiet plates, marketplace approvals and payments live here.</p><button class="btn gold" id="btn-load-plates">Load food requests</button><div id="admin-plates"></div></div>`;
  }

  function renderTerms() {
    return `${header("House rules")}<div class="card"><p>Names stay with admin. Front of student card + selfie only. Free members find work. Paid members post. Finish the jobs you accept.</p></div><button class="btn gold" data-go="home">Back</button>`;
  }

  const views = { login: renderLogin, home: renderHome, gigs: renderGigs, gig: renderGig, post: renderPost, shop: renderShop, me: renderMe, admin: renderAdmin, terms: renderTerms };

  function showWelcome(yes) {
    $("welcome").classList.toggle("hidden", !yes);
    $("nav").classList.toggle("hidden", yes);
    document.querySelector("main").style.display = yes ? "none" : "block";
  }

  async function render() {
    if (!me && view !== "login" && view !== "terms" && view !== "home") { showWelcome(true); return; }
    if (view === "home" || view === "gigs" || view === "gig") await loadGigs();
    showWelcome(false);
    Object.keys(views).forEach(k => {
      const el = $("view-" + k);
      if (!el) return;
      if (k === view) { el.classList.add("on"); el.innerHTML = views[k](); }
      else el.classList.remove("on");
    });
    document.querySelectorAll(".nav button").forEach(b => b.classList.toggle("on", b.getAttribute("data-go") === view));
    bind();
  }

  function bind() {
    document.querySelectorAll("[data-go]").forEach(b => b.onclick = () => go(b.getAttribute("data-go")));
    document.querySelectorAll("[data-open-gig]").forEach(b => b.onclick = () => { selectedGig = b.getAttribute("data-open-gig"); go("gig"); });
    const bl = $("btn-login");
    if (bl) bl.onclick = async () => {
      try { await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email: $("l-email").value, password: $("l-pass").value }) }); await loadMe(); toast("Welcome back"); go("home"); }
      catch (e) { toast(e.message); }
    };
    const br = $("btn-register");
    if (br) br.onclick = async () => {
      const body = { email: $("r-email").value, password: $("r-pass").value, first_name: $("r-first").value, surname: $("r-surname").value, student_number: $("r-num").value, course: $("r-course").value, year: $("r-year").value, stay: $("r-stay").value, gender: $("r-gender").value };
      try { await api("/api/auth/register", { method: "POST", body: JSON.stringify(body) }); await loadMe(); toast("Account created"); go("home"); }
      catch (e) { toast(e.message); }
    };
    const ba = $("btn-accept");
    if (ba) ba.onclick = async () => { await api(`/api/gigs/${selectedGig}/accept`, { method: "POST" }); toast("Accepted"); go("gigs"); };
    const bp = $("btn-post");
    if (bp) bp.onclick = async () => {
      await api("/api/gigs", { method: "POST", body: JSON.stringify({ title: $("p-title").value, detail: $("p-detail").value, pay: Number($("p-pay").value), cat: $("p-cat").value, where_text: $("p-where").value, when_text: $("p-when").value }) });
      toast("Posted"); go("gigs");
    };
    const brp = $("btn-reply");
    if (brp) brp.onclick = async () => { await api(`/api/gigs/${selectedGig}/reply`, { method: "POST", body: JSON.stringify({ body: $("reply-body").value }) }); toast("Sent privately"); };
    document.querySelectorAll("[data-buy]").forEach(b => b.onclick = async () => {
      const item = b.getAttribute("data-buy");
      const amount = Number(b.getAttribute("data-amt"));
      const d = await api("/api/payfast/checkout", { method: "POST", body: JSON.stringify({ item, amount }) });
      toast("Opening PayFast…");
      // In production the frontend posts a form to PayFast. Here we show the params.
      console.log(d);
      window.open(d.url + "?" + new URLSearchParams(d.params).toString(), "_blank");
    });
    const blo = $("btn-logout");
    if (blo) blo.onclick = async () => { await api("/api/auth/logout", { method: "POST" }); me = null; toast("Logged out"); go("login"); };
    const bap = $("btn-load-plates");
    if (bap) bap.onclick = async () => {
      const plates = await api("/api/admin/plates");
      $("admin-plates").innerHTML = plates.map(p => `<div class="admin-secret">${p.first_name} ${p.surname} · ${p.student_number}<br/>${p.need}<br/>${p.note || ""}</div>`).join("") || "<p>None</p>";
    };
  }

  document.addEventListener("click", e => {
    const g = e.target.closest("#welcome [data-go]");
    if (g) go(g.getAttribute("data-go"));
  });

  (async () => {
    await loadMe();
    if (me) go("home");
    else showWelcome(true);
  })();
})();
