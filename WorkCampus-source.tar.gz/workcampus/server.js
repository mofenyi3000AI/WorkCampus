require("dotenv").config();
const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "change-me-in-production";
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const DATA = path.join(__dirname, "data", "db.json");

function load() {
  try { return JSON.parse(fs.readFileSync(DATA, "utf8")); }
  catch { return { users: [], gigs: [], replies: [], market: [], plates: [], payments: [], nextId: 1 }; }
}
function save(d) { fs.mkdirSync(path.dirname(DATA), { recursive: true }); fs.writeFileSync(DATA, JSON.stringify(d, null, 2)); }
let db = load();
function nid() { return db.nextId++; }

if (!db.users.some(u => u.is_admin)) {
  db.users.push({
    id: nid(),
    email: process.env.ADMIN_EMAIL || "admin@ul.ac.za",
    password_hash: bcrypt.hashSync(process.env.ADMIN_PASSWORD || "admin123", 10),
    first_name: "Admin", surname: "Desk", role: "admin", is_admin: true, verified: true, plan: "premium", banned: false
  });
  save(db);
}

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

const uploadDir = path.join(__dirname, "public", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({ dest: uploadDir });

function auth(req, res, next) {
  const token = req.cookies.token || (req.headers.authorization || "").replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Login required" });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: "Invalid session" }); }
}
function adminOnly(req, res, next) {
  if (!req.user?.is_admin) return res.status(403).json({ error: "Admin only" });
  next();
}

function publicUser(u) {
  if (!u) return null;
  return { id: u.id, first_name: u.first_name, year: u.year, stay: u.stay, gender: u.gender, role: u.role, plan: u.plan, verified: !!u.verified, is_admin: !!u.is_admin };
}
function fullUser(u) {
  return { ...publicUser(u), email: u.email, surname: u.surname, student_number: u.student_number, course: u.course, banned: !!u.banned, plan_until: u.plan_until };
}

app.post("/api/auth/register", (req, res) => {
  const { email, password, first_name, surname, student_number, course, year, stay, gender } = req.body;
  if (!email || !password || !first_name || !surname || !student_number) return res.status(400).json({ error: "Missing required fields" });
  if (db.users.some(u => u.email === email)) return res.status(400).json({ error: "Email already registered" });
  const user = {
    id: nid(), email, password_hash: bcrypt.hashSync(password, 10),
    first_name, surname, student_number, course: course || "", year: year || "", stay: stay || "", gender: gender || "",
    role: "student", plan: "free", verified: false, banned: false, is_admin: false, created_at: new Date().toISOString()
  };
  db.users.push(user); save(db);
  const token = jwt.sign({ id: user.id, is_admin: false }, JWT_SECRET, { expiresIn: "30d" });
  res.cookie("token", token, { httpOnly: true, sameSite: "lax" });
  res.json({ user: fullUser(user), token });
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: "Invalid email or password" });
  const token = jwt.sign({ id: user.id, is_admin: !!user.is_admin }, JWT_SECRET, { expiresIn: "30d" });
  res.cookie("token", token, { httpOnly: true, sameSite: "lax" });
  res.json({ user: fullUser(user), token });
});

app.post("/api/auth/logout", (req, res) => { res.clearCookie("token"); res.json({ ok: true }); });

app.get("/api/me", auth, (req, res) => {
  const user = db.users.find(u => u.id === req.user.id);
  res.json({ user: fullUser(user) });
});

app.get("/api/gigs", (req, res) => {
  let isAdmin = false;
  try { isAdmin = jwt.verify(req.cookies.token || "", JWT_SECRET).is_admin; } catch {}
  const list = db.gigs.map(g => {
    const u = db.users.find(x => x.id === g.poster_id) || {};
    return {
      ...g,
      public_label: isAdmin ? `${u.first_name || ""} ${u.surname || ""}`.trim() : `Verified ${u.role === "lecturer" ? "lecturer" : "student"} · ${u.year || ""} · ${u.stay || ""}`.replace(/\s+·\s+$/, "").trim(),
      poster_name: isAdmin ? `${u.first_name || ""} ${u.surname || ""}`.trim() : null
    };
  }).sort((a, b) => b.id - a.id);
  res.json(list);
});

app.post("/api/gigs", auth, (req, res) => {
  const me = db.users.find(u => u.id === req.user.id);
  if (me.banned) return res.status(403).json({ error: "Account restricted" });
  if (me.plan === "free") return res.status(403).json({ error: "Subscribe to post jobs" });
  const { title, detail, pay, cat, where_text, when_text } = req.body;
  if (!title || !pay) return res.status(400).json({ error: "Title and pay required" });
  const gig = { id: nid(), title, detail: detail || "", pay: Number(pay), cat: cat || "other", where_text: where_text || "", when_text: when_text || "", poster_id: me.id, status: "open", hearts: 0, created_at: new Date().toISOString() };
  db.gigs.push(gig); save(db);
  res.json({ id: gig.id });
});

app.post("/api/gigs/:id/accept", auth, (req, res) => {
  const g = db.gigs.find(x => x.id == req.params.id);
  if (!g || g.status !== "open") return res.status(400).json({ error: "Gig not available" });
  g.status = "accepted"; g.accepted_by = req.user.id; save(db);
  res.json({ ok: true });
});

app.post("/api/gigs/:id/reply", auth, (req, res) => {
  const { body } = req.body;
  if (!body) return res.status(400).json({ error: "Empty" });
  db.replies.push({ id: nid(), gig_id: Number(req.params.id), from_user_id: req.user.id, body, created_at: new Date().toISOString() });
  save(db); res.json({ ok: true });
});

app.get("/api/gigs/:id/replies", auth, (req, res) => {
  const g = db.gigs.find(x => x.id == req.params.id);
  const me = db.users.find(u => u.id === req.user.id);
  if (!me.is_admin && g.poster_id !== me.id) return res.json([]);
  res.json(db.replies.filter(r => r.gig_id == req.params.id));
});

app.post("/api/plates", auth, (req, res) => {
  const { need, note } = req.body;
  const p = { id: nid(), need: need || "", note: note || "", user_id: req.user.id, status: "open", created_at: new Date().toISOString() };
  db.plates.push(p); save(db); res.json({ id: p.id });
});

app.get("/api/plates", (req, res) => {
  res.json(db.plates.filter(p => p.status !== "removed").map(p => ({ id: p.id, need: p.need, status: p.status, created_at: p.created_at })));
});

app.get("/api/admin/plates", auth, adminOnly, (req, res) => {
  res.json(db.plates.map(p => {
    const u = db.users.find(x => x.id === p.user_id) || {};
    return { ...p, first_name: u.first_name, surname: u.surname, student_number: u.student_number };
  }));
});

app.get("/api/market", (req, res) => res.json(db.market.filter(m => m.status === "live")));

app.post("/api/market", auth, (req, res) => {
  const me = db.users.find(u => u.id === req.user.id);
  if (me.plan === "free") return res.status(403).json({ error: "Subscribe to sell" });
  const { title, description, price } = req.body;
  const m = { id: nid(), title, description: description || "", price: Number(price), seller_id: me.id, status: "pending", created_at: new Date().toISOString() };
  db.market.push(m); save(db); res.json({ id: m.id });
});

app.post("/api/admin/market/:id/approve", auth, adminOnly, (req, res) => {
  const m = db.market.find(x => x.id == req.params.id);
  if (m) { m.status = "live"; save(db); }
  res.json({ ok: true });
});

// PayFast ITN — only a successful server notification upgrades the plan
app.post("/api/payfast/notify", (req, res) => {
  const data = req.body || {};
  if (data.payment_status === "COMPLETE") {
    const parts = (data.m_payment_id || "").split(":");
    const userId = parts[1] ? parseInt(parts[1], 10) : null;
    const item = parts[3] || "poster-1m";
    if (userId) {
      const user = db.users.find(u => u.id === userId);
      if (user) {
        const months = item.includes("24") ? 24 : item.includes("12") ? 12 : item.includes("6") ? 6 : 1;
        const until = new Date(); until.setMonth(until.getMonth() + months);
        user.plan = item.startsWith("pro") ? "premium" : "starter";
        user.plan_until = until.toISOString();
        db.payments.push({ id: nid(), user_id: userId, pf_payment_id: data.pf_payment_id, amount: parseFloat(data.amount_gross || 0), item, status: "COMPLETE", raw: JSON.stringify(data), created_at: new Date().toISOString() });
        save(db);
      }
    }
  }
  res.status(200).send("OK");
});

app.post("/api/payfast/checkout", auth, (req, res) => {
  const { item, amount } = req.body;
  const me = db.users.find(u => u.id === req.user.id);
  const mPaymentId = `user:${me.id}:plan:${item}`;
  const sandbox = process.env.PAYFAST_SANDBOX !== "false";
  res.json({
    url: sandbox ? "https://sandbox.payfast.co.za/eng/process" : "https://www.payfast.co.za/eng/process",
    params: {
      merchant_id: process.env.PAYFAST_MERCHANT_ID || "10000100",
      merchant_key: process.env.PAYFAST_MERCHANT_KEY || "46f0cd694581a",
      return_url: `${BASE_URL}/?paid=1`,
      cancel_url: `${BASE_URL}/?paid=0`,
      notify_url: `${BASE_URL}/api/payfast/notify`,
      name_first: me.first_name,
      name_last: me.surname,
      email_address: me.email,
      m_payment_id: mPaymentId,
      amount: Number(amount).toFixed(2),
      item_name: `Work@Campus ${item}`
    },
    note: "Set real PayFast credentials in .env. Plan upgrades only after ITN confirms COMPLETE."
  });
});

app.get("/api/health", (req, res) => res.json({ ok: true, users: db.users.length, gigs: db.gigs.length }));

app.listen(PORT, () => {
  console.log(`Work@Campus on ${BASE_URL}`);
  console.log(`Admin: ${process.env.ADMIN_EMAIL || "admin@ul.ac.za"} / ${process.env.ADMIN_PASSWORD || "admin123"}`);
});
