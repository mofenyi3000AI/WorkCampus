# Work@Campus — Multi-user version

University of Limpopo student jobs, study help, SafeWalk, quiet food requests and campus market.

## What changed from the prototype

- Real shared database (SQLite). Student A posts a gig → Student B sees it.
- Authenticated accounts (email + password). Roles: student (free seeker), paid poster, admin.
- Names stay private. Public board shows “Verified student · year · on/off campus”. Admin sees full name and student number.
- Private replies only visible to the poster and admin.
- PayFast ITN webhook (`POST /api/payfast/notify`). A successful payment upgrades the user’s plan. Button clicks or URL parameters do **not** mark a payment as successful.
- Admin desk for quiet food requests and marketplace approvals.
- Free = find work. Paid = post jobs and sell on the market.

## Quick start

```bash
cd workcampus
cp .env.example .env
# edit .env — set JWT_SECRET and PayFast credentials
npm install
npm start
```

Open http://localhost:3000

Default admin (change in .env):
- Email: admin@ul.ac.za
- Password: admin123

## PayFast

1. Create a PayFast merchant account.
2. Put Merchant ID, Key and Passphrase in `.env`.
3. Set `PAYFAST_SANDBOX=false` for live.
4. Set the ITN / Notify URL in PayFast to `https://your-domain.com/api/payfast/notify`.
5. The checkout endpoint returns the parameters to post to PayFast. On successful ITN the plan is upgraded.

Do not hard-code credentials. Use environment variables.

## Deploy

- Any Node host (Render, Railway, Fly, VPS).
- Set the environment variables.
- For production use a reverse proxy (Caddy/Nginx) and HTTPS.
- SQLite file lives in `data/workcampus.db` — back it up or switch to Postgres later.

## Next steps for UL launch

1. Put the link in UL Facebook groups.
2. Message: free to find work, R39/R79 to post.
3. Measure registrations and paid conversions.
4. Once it converts, the same engine can power Opportunity Radar and Akasia Now.
