# Get Work@Campus live (free)

## What you need
- A free GitHub account
- A free Render account
- 10–15 minutes on a laptop or iPhone browser

## Step 1 — Put the code on GitHub
1. Go to https://github.com and create a free account (use your email).
2. Create a new repository named `workcampus`.
3. On your computer, upload the entire `workcampus` folder into that repository  
   (drag and drop the files, or use GitHub’s “upload files” button).

## Step 2 — Deploy on Render
1. Go to https://render.com and sign up with the same GitHub account.
2. Click **New** → **Web Service**.
3. Connect your `workcampus` repository.
4. Render will detect the settings. Leave them as they are.
5. Under **Environment**, add these variables (click Add Environment Variable for each):

   - `JWT_SECRET` → any long random text (example: `mysecretkey123456789`)
   - `ADMIN_EMAIL` → `admin@ul.ac.za`
   - `ADMIN_PASSWORD` → a strong password you choose
   - `PAYFAST_MERCHANT_ID` → (leave blank for now)
   - `PAYFAST_MERCHANT_KEY` → (leave blank for now)
   - `PAYFAST_PASSPHRASE` → (leave blank for now)
   - `PAYFAST_SANDBOX` → `true`

6. Click **Create Web Service**.

Render will give you a link like `https://workcampus.onrender.com`.  
That is your permanent link. Use it instead of the temporary litter.catbox.moe one.

## Step 3 — Test
Open the new link in Safari.  
Log in as admin with the email and password you set above.

## Later
When you have PayFast credentials, paste them into the Render environment variables and redeploy.  
Do not put the credentials in the code.
